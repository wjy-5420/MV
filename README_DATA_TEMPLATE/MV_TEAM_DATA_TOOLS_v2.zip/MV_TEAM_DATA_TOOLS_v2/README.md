# MV 팀 배포 도구 설치

이 작은 ZIP은 데이터 ZIP을 읽는 새 Python 코드·테스트·계약 문서입니다. Git Commit/Push 없이 내부 전달하기 위해 별도 제공합니다. 기존 공개 공통 코드와 uv.lock을 교체하지 않습니다.

1. 발신자가 따로 전달한 이 ZIP의 SHA-256을 `sha256sum MV_TEAM_DATA_TOOLS_v2.zip`으로 비교합니다.
2. WSL에서 `unzip MV_TEAM_DATA_TOOLS_v2.zip -d /tmp/mv-team-tools`로 새 위치에 풉니다. 데이터 ZIP은 이곳에 풀 필요가 없습니다.
3. 자신의 MV 프로젝트 루트에서 `python3 /tmp/mv-team-tools/MV_TEAM_DATA_TOOLS_v2/install_tools.py --workspace "$PWD"`로 기존 코드와 새 파일의 해시를 검사합니다.
4. VERIFIED_ONLY면 같은 명령 끝에 `--apply`를 추가하여 새 파일만 설치합니다. 기존 파일이 다르면 중단하므로 임의로 삭제하지 말고 관리자와 버전을 맞춥니다.
5. MV 루트에서 `uv sync --locked`, `uv run --locked pytest -q tests/test_team_data_release.py tests/test_team_data_release_v2.py`, `uv run --locked python scripts/team_data_release.py --help`를 실행합니다.
6. 함께 받은 데이터 ZIP의 README_DATA.md에 따라 verify/smoke를 실행합니다. 모델 학습은 실행하지 않습니다.

설치 후 파일은 로컬 미커밋 상태입니다. 팀 소스 반영은 별도 리뷰 절차로 진행합니다. 원본 Real-IAD·승인 원장·가중치는 들어 있지 않습니다.

 v1 도구가 이미 수정된 작업 공간이면 설치기가 덮어쓰기를 거부합니다. 기존 자료를 보존하고 별도 c4b4a46 코드 복사본에 설치하거나, 변경 diff를 검토해 수동으로 통합합니다. DATA ZIP v1은 보존하고 v2를 새 폴더에 풉니다.
