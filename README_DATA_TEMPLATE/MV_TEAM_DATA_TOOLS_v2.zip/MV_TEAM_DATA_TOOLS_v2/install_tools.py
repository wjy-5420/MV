"""기존 소스 해시를 확인하고 새 도구만 설치한다. 기존 수정 파일은 덮어쓰지 않는다."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def safe(base, relative):
    p = PurePosixPath(relative)
    if p.is_absolute() or '..' in p.parts or '\\' in relative or ':' in relative:
        raise ValueError('Unsafe tool path')
    target = (base/relative).resolve()
    if not target.is_relative_to(base.resolve()):
        raise ValueError('Tool path escapes destination')
    return target

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--apply', action='store_true', help='없으면 검증만, 있으면 새 파일만 설치')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    info = json.loads((bundle/'tooling.json').read_text())
    for name, sha in info['required_existing_code_sha256'].items():
        path = safe(args.workspace, name)
        if not path.is_file() or digest(path) != sha:
            raise ValueError('Base MV code differs: '+name)
    actual = {p.relative_to(bundle/'files').as_posix() for p in (bundle/'files').rglob('*') if p.is_file()}
    if actual != set(info['new_files_sha256']):
        raise ValueError('Unexpected/missing tooling files')
    pending = []
    for name, sha in info['new_files_sha256'].items():
        source, target = safe(bundle/'files', name), safe(args.workspace, name)
        if digest(source) != sha:
            raise ValueError('Tool payload hash mismatch: '+name)
        if target.exists() and digest(target) != sha:
            raise FileExistsError('Preserve existing changes; file differs: '+name)
        if not target.exists():
            pending.append((source, target))
    if args.apply:
        for source, target in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as out:
                out.write(source.read_bytes())
    print(json.dumps(dict(status='INSTALLED' if args.apply else 'VERIFIED_ONLY', new_files=len(pending)), ensure_ascii=False))

if __name__ == '__main__':
    main()
